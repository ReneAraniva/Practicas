// Importar los módulos necesarios
const express = require('express'); // Express: Framework para manejar el servidor
const path = require('path'); // Path: Módulo para trabajar con rutas de archivos

// Configuración inicial
const app = express();
const PORT = 3000; // Puerto en el que escuchará la aplicación

// Configurar middleware para servir archivos estáticos (css, imágenes, JavaScript, etc.)
app.use(express.static('public')); // 'public' es el nombre de la carpeta que estará disponible en el servidor

// ** Rutas **
// Ruta principal (página de inicio)
app.get('/', (req, res) => {
    // Enviar el archivo 'index.html' como respuesta cuando el usuario acceda a '/'
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Ruta "Acerca de" (página secundaria)
app.get('/about', (req, res) => {
    // Enviar el archivo 'about.html' como respuesta cuando el usuario accede a '/about'
    res.sendFile(path.join(__dirname, 'views', 'about.html'));
});

// Manejo de errores (404): Cuando no se encuentra la ruta solicitada
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

// ** Iniciar el servidor **
// Escuchar peticiones en el puerto definido
app.listen(PORT, () => {
    // Mostrar un mensaje en la consola indicando que el servidor está activo
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
